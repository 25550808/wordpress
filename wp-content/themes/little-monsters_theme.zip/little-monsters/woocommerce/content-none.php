<?php
/**
 * The template for displaying a "No posts found" message
 *
 * @package WpOpal
 * @subpackage Opalhomes
 * @since Opalhomes 1.0
 */
